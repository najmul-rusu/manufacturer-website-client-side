import React from 'react';

const AllOrders = () => {
    return (
        <div>
            <h1>Hello From ALl Orders</h1>
        </div>
    );
};

export default AllOrders;