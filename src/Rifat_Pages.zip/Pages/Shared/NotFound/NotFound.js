import React from 'react';
import notfound from "../../../Images/notfound.png"
const NotFound = () => {
    return (
        <div >

            <img src={notfound} alt="" />
        </div>
    );
};

export default NotFound;