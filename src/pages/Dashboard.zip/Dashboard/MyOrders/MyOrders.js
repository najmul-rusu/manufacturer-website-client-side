import React from 'react';

const MyOrders = () => {
    return (
        <div>
            <h1>Hello from order page</h1>
        </div>
    );
};

export default MyOrders;