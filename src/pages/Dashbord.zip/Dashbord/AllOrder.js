import React from 'react';

const AllOrder = () => {
    return (
        <div>
            All Order
        </div>
    );
};

export default AllOrder;