import React from 'react';
import AllProduct from '../AllProduct/AllProduct';

const ManageProduct = () => {
    return (
        <div>
            <AllProduct/>
        </div>
    );
};

export default ManageProduct;